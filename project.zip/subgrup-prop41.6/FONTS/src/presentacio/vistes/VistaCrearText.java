package presentacio.vistes;

import javax.swing.*;
import presentacio.controladors.ControladorPresentacio;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * Classe VistaCrearText. Vista per a la creació d'un text.
 */
public class VistaCrearText {

    private JFrame frame;
    private JTextField nomTextField;
    private JTextArea contingutTextArea;
    private JComboBox<String> alfabetComboBox;

    /**
     * Constructora de la classe VistaCrearText.
     */
    public VistaCrearText() {
        initComponents();
        initUI();
    }

    /**
     * Mostra la vista.
     */
    public void mostrar() {
        frame.setVisible(true);
    }

    /**
     * Tanca la vista.
     */
    public void tancar() {
        frame.setVisible(false);
    }

    /**
     * Inicialitza els components de la vista.
     */
    private void initComponents() {
        frame = new JFrame("Crear Text");
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = GridBagConstraints.REMAINDER;

        JLabel nomLabel = new JLabel("Nom del text:");
        nomTextField = new JTextField(20);
        panel.add(nomLabel, gbc);
        panel.add(nomTextField, gbc);

        JLabel alfabetLabel = new JLabel("Seleccionar alfabet:");
        alfabetComboBox = new JComboBox<>();
        panel.add(alfabetLabel, gbc);
        panel.add(alfabetComboBox, gbc);

        JLabel contingutLabel = new JLabel("Contingut:");
        contingutTextArea = new JTextArea(15, 30);
        contingutTextArea.setLineWrap(true); // Enable line wrapping
        contingutTextArea.setWrapStyleWord(true); // Wrap lines at word boundaries
        JScrollPane scrollPane = new JScrollPane(contingutTextArea);
        panel.add(contingutLabel, gbc);
        panel.add(scrollPane, gbc);

        JButton crearButton = new JButton("Crear Text");
        crearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                crearTexto();
            }
        });

        panel.add(crearButton, gbc);

        frame.add(panel);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setLocationRelativeTo(null);
    }

    /**
     * Inicialitza els elements de la interfície.
     */
    private void initUI() {
        ArrayList<Integer> idAlfabets = ControladorPresentacio.getIdAlfabets();
        for (Integer id : idAlfabets) {
            String nombreAlfabeto = ControladorPresentacio.getNomAlfabet(id);
            alfabetComboBox.addItem(nombreAlfabeto);
        }
    }

    /**
     * Crea el text amb les dades introduïdes.
     */
    private void crearTexto() {
        String nombreEntrada = nomTextField.getText();
        String contenidoEntrada = contingutTextArea.getText();

        if (nombreEntrada.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "El nom del text no pot estar buit.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (contenidoEntrada.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "El contingut del text no pot estar buit.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int indiceSeleccionado = alfabetComboBox.getSelectedIndex();
        if (indiceSeleccionado != -1) {
            ArrayList<Integer> idAlfabets = ControladorPresentacio.getIdAlfabets();
            Integer idAlfabetSeleccionado = idAlfabets.get(indiceSeleccionado);
            try {
                ControladorPresentacio.crearText(nombreEntrada, contenidoEntrada, idAlfabetSeleccionado);
                JOptionPane.showMessageDialog(frame, "Text creat correctament.", "Èxit", JOptionPane.INFORMATION_MESSAGE);
                frame.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error en crear el text.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(frame, "No s'ha seleccionat cap alfabet.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
