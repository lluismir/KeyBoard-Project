package domini.classes;

import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

/**
 * Classe Teclat. Representa un teclat dins del sistema amb una distribució específica de caràcters,
 * així com informació relacionada amb el seu nom, dimensions, identificador i l'entrada vinculada.
 */
public class Teclat {

    // ---------------------------------------------------------------------------- //
    //                                   Atributs
    // ---------------------------------------------------------------------------- //

    protected ArrayList<Character> distribucio;
    protected String nom;
    protected Integer numFiles;
    protected Integer numColumnes;
    protected Integer idEntrada;
    protected Integer id;
    protected Integer tipus;

    // ---------------------------------------------------------------------------- //
    //                                   Constructora
    // ---------------------------------------------------------------------------- //

    /**
     * Constructora de Teclat.
     * @param nom Nom del teclat
     * @param distribucio Distribució de caràcters del teclat ordenats per files
     * @param idEntrada Identificador de l'entrada vinculada al teclat
     * @param numFiles Nombre de files del teclat
     * @param numColumnes Nombre de columnes del teclat
     * @param id Identificador únic del teclat
     * @param tipus Tipus de teclat
     */
    public Teclat(String nom, ArrayList<Character> distribucio, Integer idEntrada, Integer numFiles, Integer numColumnes, Integer id, Integer tipus) {
        if (numFiles * numColumnes < distribucio.size()) throw new IllegalArgumentException("Tamany introduit inferior al nombre de lletres");
        this.distribucio = distribucio;
        this.idEntrada = idEntrada;
        this.numFiles = numFiles;
        this.numColumnes = numColumnes;
        this.id = id;
        this.nom = nom;
        this.tipus = tipus;
    }

    /**
     * Modificadora de les files i columnes del teclat.
     * @param files Nombre de files del teclat
     * @param columnes Nombre de columnes del teclat
     * @throws Exception Si el nombre de files o columnes és negatiu o si el nombre de files * columnes és inferior al nombre de lletres
     */
    public void modificarFilesColumnes(int files, int columnes) throws Exception {
        if (files * columnes < distribucio.size()) throw new Exception("Tamany inferior al nombre de lletres");
        if (files < 0) throw new Exception("Hi ha d'haver minim una fila");
        if (columnes < 0) throw new Exception("Hi ha d'haver minim una columna");
        numFiles = files;
        numColumnes = columnes;
    }

    /**
     * Modificadora del nom del teclat.
     * @param nom Nom del teclat
     * @throws Exception Si el nom és buit
     */
    public void modificarNom(String nom) throws Exception {
        if (nom.isEmpty()) throw new Exception("El nom no pot ser buit");
        this.nom = nom;
    }

    /**
     * Setter de la distribució de caràcters del teclat.
     * @param novaDistribucio ArrayList de caràcters amb la nova distribució del teclat.
     */
    public void setDistribucio(ArrayList<Character> novaDistribucio) {
        distribucio = novaDistribucio;
    } 

    // ---------------------------------------------------------------------------- //
    //                                   Getters
    // ---------------------------------------------------------------------------- //

    /**
     * Retorna la distribució de caràcters del teclat.
     * @return ArrayList de caràcters amb la distribució del teclat.
     */
    public ArrayList<Character> getDistribucio() {
        return this.distribucio;
    }

    /**
     * Retorna el nombre de files del teclat.
     * @return Integer amb el nombre de files del teclat.
     */
    public Integer getFiles() {
        return this.numFiles;
    }

    /**
     * Retorna el nom del teclat.
     * @return String amb el nom del teclat.
     */
    public String getNom() {
        return nom;
    }

    /**
     * Retorna el nombre de columnes del teclat.
     * @return Integer amb el nombre de columnes del teclat.
     */
    public Integer getColumnes() {
        return this.numColumnes;
    }

    /**
     * Retorna l'identificador de l'entrada vinculada al teclat.
     * @return Integer amb l'identificador de l'entrada vinculada.
     */
    public Integer getIdEntradaVinculada() {
        return this.idEntrada;
    }

    /**
     * Retorna el tipus de teclat.
     * @return
     */
    public Integer getTipus() {
        return tipus;
    }

    /**
     * Retorna el nombre optim de files del teclat donat el nombre de columnes.
     * @param numCols
     * @return
     */
    public Integer getFilesOptimes(Integer numCols) {
        if (numCols == null || numCols == 0) {
            throw new IllegalArgumentException("numCols is null or zero");
        }
        long nonRepeatedCount = distribucio.stream().distinct().count();
        return (int) Math.ceil((double) nonRepeatedCount / numCols);
    }

    /**
     * Retorna el nombre optim de columnes del teclat donat el nombre de files.
     * @param numFiles
     * @return
     */
    public Integer getColumnesOptimesTeclat(Integer numFiles) {
        if (numFiles == null || numFiles == 0) {
            throw new IllegalArgumentException("numFiles is null or zero");
        }
        long nonRepeatedCount = distribucio.stream().distinct().count();
        return (int) Math.ceil((double) nonRepeatedCount / numFiles);
    }
}
