# PROP Grup 41.6

Projecte de Programació, Grup41, subgrup 41.1.
Professor: Jordi Turmo (turmo@cs.upc.edu).
Membres del grup

    Lluis Mir Agusti (lluis.mir.agusti@estudiantat.upc.edu)
    Jordi Homedes (jordi.homedes@estudiantat.upc.edu)
    Marc Nafria (marc.nafria@estudiantat.upc.edu)
    Pol Plana (pol.plana@estudiantat.upc.edu)

#### Com executar la practica

Desde el directori `./FONTS/`:

+ `make all`: compila tots els arxius .java especificats i els col·loca en el directori de sortida.

+ `make jars`: compila tots els arxius .java especificats, incloent els controladors, i després crea un arxiu .jar utilitzant el manifest DriverControladorAlgoritme.mf.

+ `make executaDriverControladorAlgoritme`: executa l'arxiu .jar creat en la comanda make jars.

+ `make [NomClasseTest]`: executa les proves unitaries de la classe utilitzant JUnit.
